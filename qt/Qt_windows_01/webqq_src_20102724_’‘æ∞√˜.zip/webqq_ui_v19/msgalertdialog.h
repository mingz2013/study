#ifndef MSGALERTDIALOG_H
#define MSGALERTDIALOG_H

#include <QDialog>
#include "myjson.h"
#include <QMouseEvent>

namespace Ui {
class MsgAlertDialog;
}

class MsgAlertDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit MsgAlertDialog(QVariant var, bool isButty = true, QWidget *parent = 0);
    ~MsgAlertDialog();
    void setMsg(QJsonObject item_value);

     QString from_uin;
     QString group_uin;
     QVariant var_chatDialog;
    
private slots:
    void on_pushButton_Close_clicked();

private:
    Ui::MsgAlertDialog *ui;

    bool isButty;



    QPoint windowPos, dPos, mousePos;// 移动相关

    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void closeEvent(QCloseEvent *event);
    void mouseDoubleClickEvent(QMouseEvent *event);
};

#endif // MSGALERTDIALOG_H
