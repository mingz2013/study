#include "globalset.h"
// 声明全局变量
GlobalSet globalset ;
