#ifndef MSGLISTDIALOG_H
#define MSGLISTDIALOG_H

#include <QDialog>
#include <QMouseEvent>

namespace Ui {
class MsgListDialog;
}

class MsgListDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit MsgListDialog(QWidget *parent = 0);
    ~MsgListDialog();
    
private:
    Ui::MsgListDialog *ui;
    QPoint windowPos, dPos, mousePos;// 移动相关

    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);

};

#endif // MSGLISTDIALOG_H
