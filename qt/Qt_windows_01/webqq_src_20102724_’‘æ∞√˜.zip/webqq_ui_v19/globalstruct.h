#ifndef INIT_H
#define INIT_H

#include <QNetworkCookie>
#include <QString>
#include "chatdialog.h"
#include "groupchatdialog.h"
#include <QMap>
#include <QList>
#include "msgalertdialog.h"
#include <QHash>
#include "maindialog.h"

typedef struct Msg_Struct{
    QString uin;
    QVariant var_Info;
    QList<QJsonObject> list_Msg;
}MSG_STRUCT;




typedef struct Other_Struct{
    QList<ChatDialog*> chatDialog_List;    // 窗口指针列表
    QList<GroupChatDialog*> groupDialog_List;    // 群窗口指针列表
    QList<MsgAlertDialog*> msgAlertDialog_List; // 提示框列表
    //QMap<QString, QList<QJsonObject> > puttyMsgMap;
   // QMap<QString, QHash<QVariant, QList<QJsonObject> > > groupMsgMap;
   // QMap<QString, QMap<QJsonObject, QList<QJsonObject> > > puttyMsgMap;
    QList<MSG_STRUCT> puttyMsgList;
    QList<MSG_STRUCT> groupMsgList;

    MainDialog*maindialog;

}OTHER;




#endif // INIT_H
