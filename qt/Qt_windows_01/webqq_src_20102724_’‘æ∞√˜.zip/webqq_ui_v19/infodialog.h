#ifndef INFODIALOG_H
#define INFODIALOG_H

#include <QDialog>

namespace Ui {
class InfoDialog;
}

class InfoDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit InfoDialog(QWidget *parent = 0);
    ~InfoDialog();
    
private:
    Ui::InfoDialog *ui;
    QPoint windowPos, dPos, mousePos;// 移动相关

    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
};

#endif // INFODIALOG_H
