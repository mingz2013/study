#include "msglistdialog.h"
#include "ui_msglistdialog.h"

MsgListDialog::MsgListDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MsgListDialog)
{
    ui->setupUi(this);

    setWindowOpacity(1);
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowSystemMenuHint | Qt::WindowMinimizeButtonHint);
    setAttribute(Qt::WA_TranslucentBackground);
}

MsgListDialog::~MsgListDialog()
{
    delete ui;
}

void MsgListDialog::mouseMoveEvent(QMouseEvent *event){
    this->move(event->globalPos() - this->dPos);
    QDialog::mouseMoveEvent(event);
}

void MsgListDialog::mousePressEvent(QMouseEvent *event){
    this->windowPos = this->pos();
    this->mousePos = event->globalPos();
    this->dPos = mousePos - windowPos;
    QDialog::mousePressEvent(event);
}
