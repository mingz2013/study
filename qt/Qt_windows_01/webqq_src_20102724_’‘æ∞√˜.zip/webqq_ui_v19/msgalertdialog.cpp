#include "msgalertdialog.h"
#include "ui_msgalertdialog.h"
#include "globalset.h"
#include "chatdialog.h"
#include "groupchatdialog.h"






extern GlobalSet globalset;// 引用全局变量

MsgAlertDialog::MsgAlertDialog(QVariant var, bool isButty, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MsgAlertDialog)
{
    ui->setupUi(this);
    setWindowOpacity(1);
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowSystemMenuHint | Qt::WindowMinimizeButtonHint);
    setAttribute(Qt::WA_TranslucentBackground);

    this->var_chatDialog = var;
    this->isButty = isButty;

    if(isButty){
        from_uin = QString::number((qulonglong)(var_chatDialog.toJsonObject().value("uin").toDouble()));
        QString nick = var_chatDialog.toJsonObject().value("nick").toString();
         qDebug() << var_chatDialog.toJsonObject();
         qDebug() << "nick------->" << nick;
         ui->label_MainName->setText(nick);

    }else{
        group_uin = QString::number((qulonglong)var_chatDialog.toJsonObject().value("gid").toDouble());
        QString name = var_chatDialog.toJsonObject().value("name").toString();
         qDebug() << var_chatDialog.toJsonObject();
         qDebug() << "name------->" << name;
         ui->label_MainName->setText(name);

    }




}

MsgAlertDialog::~MsgAlertDialog()
{
    delete ui;
}

void MsgAlertDialog::mouseMoveEvent(QMouseEvent *event){
    this->move(event->globalPos() - this->dPos);
    QDialog::mouseMoveEvent(event);
}

void MsgAlertDialog::mousePressEvent(QMouseEvent *event){
    this->windowPos = this->pos();
    this->mousePos = event->globalPos();
    this->dPos = mousePos - windowPos;
    QDialog::mousePressEvent(event);
}
void MsgAlertDialog::mouseDoubleClickEvent(QMouseEvent *event){
    if(isButty){
        ChatDialog *chatDialog = new ChatDialog(var_chatDialog);
        chatDialog->show();
        this->close();
    }else{
        // 如果窗口未打开，则打开窗口，并加入列表
        GroupChatDialog *groupChatDialog = new GroupChatDialog(var_chatDialog);
        groupChatDialog->show();
        this->close();
    }
    QDialog::mouseDoubleClickEvent(event);
}

void MsgAlertDialog::on_pushButton_Close_clicked()
{
    this->close();
}

void MsgAlertDialog::setMsg(QJsonObject item_value)
{

  //  if(isButty){
        QString content_text = item_value.value("content").toArray().last().toString();
        ui->textEdit_Msg->setText(content_text);
        //ui->label_MainName->setText(from_uin);
    /*}else{
        QString content_text = item_value.value("content").toArray().last().toString();
        ui->textEdit_Msg->setText(content_text);
        //ui->label_MainName->setText(from_uin);
    }
    */
}

void MsgAlertDialog::closeEvent(QCloseEvent *event)
{
    globalset.other_struct.msgAlertDialog_List.removeOne(this);
    QDialog::closeEvent(event);
}
