﻿namespace GroupMsg_v0._1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox_programLog = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.listView_postLog = new System.Windows.Forms.ListView();
            this.columnHeader_time = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_QQGroup = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_member = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_content = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_isRight = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_result = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.listView_QQGroupList = new System.Windows.Forms.ListView();
            this.columnHeader_GroupNmae = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button_lock_repleace = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_replaceList = new System.Windows.Forms.TextBox();
            this.textBox_replaceWord = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button_lock_hack = new System.Windows.Forms.Button();
            this.textBox_blackWordList = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button_lock_Tel = new System.Windows.Forms.Button();
            this.textBox_TelList = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.button_lock_keyword = new System.Windows.Forms.Button();
            this.textBox_keyWordList = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.button_lock_other = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox_city = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.numericUpDown_high = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.numericUpDown_low = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_host = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_QQNumber = new System.Windows.Forms.TextBox();
            this.textBox_pwd = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_verifycode = new System.Windows.Forms.TextBox();
            this.pictureBox_verifyimage = new System.Windows.Forms.PictureBox();
            this.button_login = new System.Windows.Forms.Button();
            this.linkLabel_verifyChange = new System.Windows.Forms.LinkLabel();
            this.groupBox_login = new System.Windows.Forms.GroupBox();
            this.textBox_Show = new System.Windows.Forms.TextBox();
            this.textBox_nick_Show = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_high)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_low)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_verifyimage)).BeginInit();
            this.groupBox_login.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Location = new System.Drawing.Point(12, 114);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(771, 326);
            this.tabControl1.TabIndex = 9;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBox_programLog);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(763, 300);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "程序日志";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox_programLog
            // 
            this.textBox_programLog.AcceptsReturn = true;
            this.textBox_programLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_programLog.Location = new System.Drawing.Point(6, 6);
            this.textBox_programLog.Multiline = true;
            this.textBox_programLog.Name = "textBox_programLog";
            this.textBox_programLog.ReadOnly = true;
            this.textBox_programLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_programLog.Size = new System.Drawing.Size(751, 288);
            this.textBox_programLog.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.listView_postLog);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(763, 300);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "发布日志";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // listView_postLog
            // 
            this.listView_postLog.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader_time,
            this.columnHeader_QQGroup,
            this.columnHeader_member,
            this.columnHeader_content,
            this.columnHeader_isRight,
            this.columnHeader_result});
            this.listView_postLog.Location = new System.Drawing.Point(6, 6);
            this.listView_postLog.Name = "listView_postLog";
            this.listView_postLog.Size = new System.Drawing.Size(751, 288);
            this.listView_postLog.TabIndex = 0;
            this.listView_postLog.UseCompatibleStateImageBehavior = false;
            this.listView_postLog.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader_time
            // 
            this.columnHeader_time.Text = "时间";
            this.columnHeader_time.Width = 83;
            // 
            // columnHeader_QQGroup
            // 
            this.columnHeader_QQGroup.Text = "QQ群";
            this.columnHeader_QQGroup.Width = 100;
            // 
            // columnHeader_member
            // 
            this.columnHeader_member.Text = "成员";
            this.columnHeader_member.Width = 134;
            // 
            // columnHeader_content
            // 
            this.columnHeader_content.Text = "内容";
            this.columnHeader_content.Width = 238;
            // 
            // columnHeader_isRight
            // 
            this.columnHeader_isRight.Text = "发布";
            // 
            // columnHeader_result
            // 
            this.columnHeader_result.Text = "结果";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.listView_QQGroupList);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(763, 300);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "QQ群列表";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // listView_QQGroupList
            // 
            this.listView_QQGroupList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader_GroupNmae});
            this.listView_QQGroupList.Location = new System.Drawing.Point(6, 6);
            this.listView_QQGroupList.Name = "listView_QQGroupList";
            this.listView_QQGroupList.Size = new System.Drawing.Size(751, 291);
            this.listView_QQGroupList.TabIndex = 0;
            this.listView_QQGroupList.UseCompatibleStateImageBehavior = false;
            this.listView_QQGroupList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader_GroupNmae
            // 
            this.columnHeader_GroupNmae.Text = "群昵称";
            this.columnHeader_GroupNmae.Width = 400;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button_lock_repleace);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.textBox_replaceList);
            this.tabPage4.Controls.Add(this.textBox_replaceWord);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(763, 300);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "字符替换列表";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button_lock_repleace
            // 
            this.button_lock_repleace.Location = new System.Drawing.Point(682, 5);
            this.button_lock_repleace.Name = "button_lock_repleace";
            this.button_lock_repleace.Size = new System.Drawing.Size(75, 23);
            this.button_lock_repleace.TabIndex = 4;
            this.button_lock_repleace.Text = "编辑解锁";
            this.button_lock_repleace.UseVisualStyleBackColor = true;
            this.button_lock_repleace.Click += new System.EventHandler(this.button_lock_repleace_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(197, 12);
            this.label5.TabIndex = 3;
            this.label5.Text = "被替换的关键字（请用逗号分隔）：";
            // 
            // textBox_replaceList
            // 
            this.textBox_replaceList.Location = new System.Drawing.Point(9, 60);
            this.textBox_replaceList.Multiline = true;
            this.textBox_replaceList.Name = "textBox_replaceList";
            this.textBox_replaceList.ReadOnly = true;
            this.textBox_replaceList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_replaceList.Size = new System.Drawing.Size(748, 234);
            this.textBox_replaceList.TabIndex = 2;
            this.textBox_replaceList.Leave += new System.EventHandler(this.textBox_replaceList_Leave);
            // 
            // textBox_replaceWord
            // 
            this.textBox_replaceWord.Location = new System.Drawing.Point(241, 7);
            this.textBox_replaceWord.Name = "textBox_replaceWord";
            this.textBox_replaceWord.ReadOnly = true;
            this.textBox_replaceWord.Size = new System.Drawing.Size(419, 21);
            this.textBox_replaceWord.TabIndex = 1;
            this.textBox_replaceWord.Leave += new System.EventHandler(this.textBox_replaceWord_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(227, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "替换为（输入为空则替换为一个空格 ）：";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button_lock_hack);
            this.tabPage5.Controls.Add(this.textBox_blackWordList);
            this.tabPage5.Controls.Add(this.label6);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(763, 300);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "黑名单";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button_lock_hack
            // 
            this.button_lock_hack.Location = new System.Drawing.Point(682, 7);
            this.button_lock_hack.Name = "button_lock_hack";
            this.button_lock_hack.Size = new System.Drawing.Size(75, 23);
            this.button_lock_hack.TabIndex = 2;
            this.button_lock_hack.Text = "编辑解锁";
            this.button_lock_hack.UseVisualStyleBackColor = true;
            this.button_lock_hack.Click += new System.EventHandler(this.button_lock_hack_Click);
            // 
            // textBox_blackWordList
            // 
            this.textBox_blackWordList.Location = new System.Drawing.Point(9, 35);
            this.textBox_blackWordList.Multiline = true;
            this.textBox_blackWordList.Name = "textBox_blackWordList";
            this.textBox_blackWordList.ReadOnly = true;
            this.textBox_blackWordList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_blackWordList.Size = new System.Drawing.Size(748, 259);
            this.textBox_blackWordList.TabIndex = 1;
            this.textBox_blackWordList.Leave += new System.EventHandler(this.textBox_blackWordList_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(281, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "如果信息中包含下列之一则不上传（请用逗号分隔）";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button_lock_Tel);
            this.tabPage6.Controls.Add(this.textBox_TelList);
            this.tabPage6.Controls.Add(this.label7);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(763, 300);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "电话列表";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button_lock_Tel
            // 
            this.button_lock_Tel.Location = new System.Drawing.Point(682, 7);
            this.button_lock_Tel.Name = "button_lock_Tel";
            this.button_lock_Tel.Size = new System.Drawing.Size(75, 23);
            this.button_lock_Tel.TabIndex = 2;
            this.button_lock_Tel.Text = "编辑解锁";
            this.button_lock_Tel.UseVisualStyleBackColor = true;
            this.button_lock_Tel.Click += new System.EventHandler(this.button_lock_Tel_Click);
            // 
            // textBox_TelList
            // 
            this.textBox_TelList.Location = new System.Drawing.Point(9, 34);
            this.textBox_TelList.MaxLength = 0;
            this.textBox_TelList.Multiline = true;
            this.textBox_TelList.Name = "textBox_TelList";
            this.textBox_TelList.ReadOnly = true;
            this.textBox_TelList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_TelList.Size = new System.Drawing.Size(748, 270);
            this.textBox_TelList.TabIndex = 1;
            this.textBox_TelList.Leave += new System.EventHandler(this.textBox_TelList_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(491, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "如果上传的QQ号包含在此，则附加上此处的电话信息（信息格式：QQ号1:电话,QQ号2:电话）";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.button_lock_keyword);
            this.tabPage7.Controls.Add(this.textBox_keyWordList);
            this.tabPage7.Controls.Add(this.label8);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(763, 300);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "关键词设置";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // button_lock_keyword
            // 
            this.button_lock_keyword.Location = new System.Drawing.Point(682, 6);
            this.button_lock_keyword.Name = "button_lock_keyword";
            this.button_lock_keyword.Size = new System.Drawing.Size(75, 23);
            this.button_lock_keyword.TabIndex = 2;
            this.button_lock_keyword.Text = "编辑解锁";
            this.button_lock_keyword.UseVisualStyleBackColor = true;
            this.button_lock_keyword.Click += new System.EventHandler(this.button_lock_keyword_Click);
            // 
            // textBox_keyWordList
            // 
            this.textBox_keyWordList.Location = new System.Drawing.Point(9, 35);
            this.textBox_keyWordList.Multiline = true;
            this.textBox_keyWordList.Name = "textBox_keyWordList";
            this.textBox_keyWordList.ReadOnly = true;
            this.textBox_keyWordList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_keyWordList.Size = new System.Drawing.Size(748, 265);
            this.textBox_keyWordList.TabIndex = 1;
            this.textBox_keyWordList.Leave += new System.EventHandler(this.textBox_keyWordList_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(509, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "只有包含关键词的信息才会被采集，如果关键词为空则采集所有信息，关键词之间请用逗号分隔\r\n";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.button_lock_other);
            this.tabPage8.Controls.Add(this.textBox1);
            this.tabPage8.Controls.Add(this.textBox_city);
            this.tabPage8.Controls.Add(this.label12);
            this.tabPage8.Controls.Add(this.numericUpDown_high);
            this.tabPage8.Controls.Add(this.label11);
            this.tabPage8.Controls.Add(this.numericUpDown_low);
            this.tabPage8.Controls.Add(this.label10);
            this.tabPage8.Controls.Add(this.textBox_host);
            this.tabPage8.Controls.Add(this.label9);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(763, 300);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "其它设置";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // button_lock_other
            // 
            this.button_lock_other.Location = new System.Drawing.Point(286, 120);
            this.button_lock_other.Name = "button_lock_other";
            this.button_lock_other.Size = new System.Drawing.Size(75, 23);
            this.button_lock_other.TabIndex = 9;
            this.button_lock_other.Text = "编辑解锁";
            this.button_lock_other.UseVisualStyleBackColor = true;
            this.button_lock_other.Click += new System.EventHandler(this.button_lock_other_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(382, 11);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(375, 283);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "软件信息：";
            // 
            // textBox_city
            // 
            this.textBox_city.Location = new System.Drawing.Point(78, 77);
            this.textBox_city.Name = "textBox_city";
            this.textBox_city.ReadOnly = true;
            this.textBox_city.Size = new System.Drawing.Size(283, 21);
            this.textBox_city.TabIndex = 7;
            this.textBox_city.Leave += new System.EventHandler(this.textBox_city_Leave);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 81);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 6;
            this.label12.Text = "发布城市：";
            // 
            // numericUpDown_high
            // 
            this.numericUpDown_high.Location = new System.Drawing.Point(241, 43);
            this.numericUpDown_high.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numericUpDown_high.Name = "numericUpDown_high";
            this.numericUpDown_high.ReadOnly = true;
            this.numericUpDown_high.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown_high.TabIndex = 5;
            this.numericUpDown_high.Leave += new System.EventHandler(this.numericUpDown_high_Leave);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(206, 47);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 4;
            this.label11.Text = "——";
            // 
            // numericUpDown_low
            // 
            this.numericUpDown_low.Location = new System.Drawing.Point(79, 43);
            this.numericUpDown_low.Name = "numericUpDown_low";
            this.numericUpDown_low.ReadOnly = true;
            this.numericUpDown_low.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown_low.TabIndex = 3;
            this.numericUpDown_low.Leave += new System.EventHandler(this.numericUpDown_low_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 2;
            this.label10.Text = "信息长度：";
            // 
            // textBox_host
            // 
            this.textBox_host.Location = new System.Drawing.Point(78, 10);
            this.textBox_host.Name = "textBox_host";
            this.textBox_host.ReadOnly = true;
            this.textBox_host.Size = new System.Drawing.Size(283, 21);
            this.textBox_host.TabIndex = 1;
            this.textBox_host.Leave += new System.EventHandler(this.textBox_host_Leave);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "域名设置：";
            // 
            // textBox_QQNumber
            // 
            this.textBox_QQNumber.Location = new System.Drawing.Point(77, 7);
            this.textBox_QQNumber.Name = "textBox_QQNumber";
            this.textBox_QQNumber.Size = new System.Drawing.Size(172, 21);
            this.textBox_QQNumber.TabIndex = 0;
            this.textBox_QQNumber.Leave += new System.EventHandler(this.textBox_QQNumber_Leave);
            // 
            // textBox_pwd
            // 
            this.textBox_pwd.Location = new System.Drawing.Point(77, 35);
            this.textBox_pwd.Name = "textBox_pwd";
            this.textBox_pwd.PasswordChar = '*';
            this.textBox_pwd.Size = new System.Drawing.Size(172, 21);
            this.textBox_pwd.TabIndex = 1;
            this.textBox_pwd.Leave += new System.EventHandler(this.textBox_pwd_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "账    号：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "密    码：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "验 证 码：";
            // 
            // textBox_verifycode
            // 
            this.textBox_verifycode.Location = new System.Drawing.Point(77, 60);
            this.textBox_verifycode.Name = "textBox_verifycode";
            this.textBox_verifycode.Size = new System.Drawing.Size(172, 21);
            this.textBox_verifycode.TabIndex = 5;
            this.textBox_verifycode.Leave += new System.EventHandler(this.textBox_verifycode_Leave);
            // 
            // pictureBox_verifyimage
            // 
            this.pictureBox_verifyimage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_verifyimage.Location = new System.Drawing.Point(255, 7);
            this.pictureBox_verifyimage.Name = "pictureBox_verifyimage";
            this.pictureBox_verifyimage.Size = new System.Drawing.Size(131, 50);
            this.pictureBox_verifyimage.TabIndex = 6;
            this.pictureBox_verifyimage.TabStop = false;
            this.pictureBox_verifyimage.Click += new System.EventHandler(this.pictureBox_verifyimage_Click);
            // 
            // button_login
            // 
            this.button_login.Location = new System.Drawing.Point(255, 59);
            this.button_login.Name = "button_login";
            this.button_login.Size = new System.Drawing.Size(178, 23);
            this.button_login.TabIndex = 7;
            this.button_login.Text = "登陆";
            this.button_login.UseVisualStyleBackColor = true;
            this.button_login.Click += new System.EventHandler(this.button_login_Click);
            // 
            // linkLabel_verifyChange
            // 
            this.linkLabel_verifyChange.AutoSize = true;
            this.linkLabel_verifyChange.Location = new System.Drawing.Point(392, 44);
            this.linkLabel_verifyChange.Name = "linkLabel_verifyChange";
            this.linkLabel_verifyChange.Size = new System.Drawing.Size(41, 12);
            this.linkLabel_verifyChange.TabIndex = 8;
            this.linkLabel_verifyChange.TabStop = true;
            this.linkLabel_verifyChange.Text = "换一张";
            this.linkLabel_verifyChange.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_verifyChange_LinkClicked);
            // 
            // groupBox_login
            // 
            this.groupBox_login.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_login.Controls.Add(this.linkLabel_verifyChange);
            this.groupBox_login.Controls.Add(this.button_login);
            this.groupBox_login.Controls.Add(this.pictureBox_verifyimage);
            this.groupBox_login.Controls.Add(this.textBox_verifycode);
            this.groupBox_login.Controls.Add(this.label3);
            this.groupBox_login.Controls.Add(this.label2);
            this.groupBox_login.Controls.Add(this.label1);
            this.groupBox_login.Controls.Add(this.textBox_pwd);
            this.groupBox_login.Controls.Add(this.textBox_QQNumber);
            this.groupBox_login.Location = new System.Drawing.Point(12, 12);
            this.groupBox_login.Name = "groupBox_login";
            this.groupBox_login.Size = new System.Drawing.Size(458, 96);
            this.groupBox_login.TabIndex = 8;
            this.groupBox_login.TabStop = false;
            // 
            // textBox_Show
            // 
            this.textBox_Show.AcceptsReturn = true;
            this.textBox_Show.Location = new System.Drawing.Point(500, 71);
            this.textBox_Show.Multiline = true;
            this.textBox_Show.Name = "textBox_Show";
            this.textBox_Show.ReadOnly = true;
            this.textBox_Show.Size = new System.Drawing.Size(273, 37);
            this.textBox_Show.TabIndex = 10;
            this.textBox_Show.Text = "提示信息：";
            // 
            // textBox_nick_Show
            // 
            this.textBox_nick_Show.Location = new System.Drawing.Point(500, 19);
            this.textBox_nick_Show.Multiline = true;
            this.textBox_nick_Show.Name = "textBox_nick_Show";
            this.textBox_nick_Show.ReadOnly = true;
            this.textBox_nick_Show.Size = new System.Drawing.Size(273, 44);
            this.textBox_nick_Show.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 452);
            this.Controls.Add(this.textBox_nick_Show);
            this.Controls.Add(this.textBox_Show);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox_login);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "GroupMsg";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_high)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_low)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_verifyimage)).EndInit();
            this.groupBox_login.ResumeLayout(false);
            this.groupBox_login.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TextBox textBox_programLog;
        private System.Windows.Forms.ListView listView_postLog;
        private System.Windows.Forms.ColumnHeader columnHeader_time;
        private System.Windows.Forms.ColumnHeader columnHeader_QQGroup;
        private System.Windows.Forms.ColumnHeader columnHeader_member;
        private System.Windows.Forms.ColumnHeader columnHeader_content;
        private System.Windows.Forms.ColumnHeader columnHeader_isRight;
        private System.Windows.Forms.ColumnHeader columnHeader_result;
        private System.Windows.Forms.ListView listView_QQGroupList;
        private System.Windows.Forms.TextBox textBox_replaceWord;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_replaceList;
        private System.Windows.Forms.TextBox textBox_blackWordList;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_TelList;
        private System.Windows.Forms.TextBox textBox_keyWordList;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_city;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown numericUpDown_high;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numericUpDown_low;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_host;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox_QQNumber;
        private System.Windows.Forms.TextBox textBox_pwd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_verifycode;
        private System.Windows.Forms.PictureBox pictureBox_verifyimage;
        private System.Windows.Forms.Button button_login;
        private System.Windows.Forms.LinkLabel linkLabel_verifyChange;
        private System.Windows.Forms.GroupBox groupBox_login;
        private System.Windows.Forms.TextBox textBox_Show;
        private System.Windows.Forms.ColumnHeader columnHeader_GroupNmae;
        private System.Windows.Forms.TextBox textBox_nick_Show;
        private System.Windows.Forms.Button button_lock_repleace;
        private System.Windows.Forms.Button button_lock_hack;
        private System.Windows.Forms.Button button_lock_Tel;
        private System.Windows.Forms.Button button_lock_keyword;
        private System.Windows.Forms.Button button_lock_other;

        
    }
}

